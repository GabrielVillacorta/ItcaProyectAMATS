
package exapract2;

import javax.swing.JOptionPane;


public class ExaPract2 {
    public static void main(String[] args) {
        int cant =0;  
        cant = Integer.parseInt(JOptionPane.showInputDialog("Cuantos Empleados registrara?"));
        String nombreEmpleado [] = new String [cant];
        double salarioHora [] = new double [cant];
        int horasTrabajadad [] = new int[cant];
        String planilla ="Detalle de la planilla \n";
        double totalPlanilla= 0;
        double salarioMayor = 0;
        String nombremayor ="";
        
        
        
        
        for (int i = 0; i < cant; i++) {
            nombreEmpleado [i] = JOptionPane.showInputDialog("Digite el nombre del empleado -->" +(i+1));
            salarioHora [i] = Double.parseDouble(JOptionPane.showInputDialog("Digite el salario por hora del empleado --> "+(i+1)));
            horasTrabajadad [i] = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de horas trabajadas del empleado --> "+(i+1)));
            totalPlanilla += salarioHora [i] * horasTrabajadad[i];
            
            planilla += "\n\n Empleado : "+nombreEmpleado[i]+"\n Salario por hora : $"+salarioHora[i]+ "\n Cantidad de Horas trabajadas : "+horasTrabajadad[i] + "\nEl empleado gano un total de : "+(salarioHora[i]*horasTrabajadad[i]) ; 
            
            if (salarioHora[i] > salarioMayor) {
                salarioMayor = salarioHora[i];
                nombremayor = nombreEmpleado[i];
                
            }
            
            
        }
        JOptionPane.showMessageDialog(null, planilla + "\n \n EL total de la planilla es de : $"+totalPlanilla);
        JOptionPane.showMessageDialog(null, "EL empleado que mas gano fue: "+nombremayor);
    }
    
}
